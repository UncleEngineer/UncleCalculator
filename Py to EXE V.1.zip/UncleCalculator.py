#UncleCalculator.py
from tkinter import *
from tkinter import ttk, messagebox #theme of Tk

GUI = Tk()
GUI.title('Uncle Calculator V.0.1')
GUI.geometry('500x300')
GUI.iconbitmap('calculator.ico')
#### FONT ####
FONT1 = ('impact',30)
FONT2 = ('Angsana New',20)

L = ttk.Label(GUI,text='กรุณากรอกรัศมีวงกลม (เมตร)',font=FONT2).pack(pady=10)

v_radius = StringVar() # กรอกเสร็จเก็บจุดนี้

E1 = ttk.Entry(GUI,textvariable=v_radius,font=FONT1)
E1.pack(pady=20)
E1.focus()

def Calculate(event=None):
	try:
		unit = 'ตร.ม.'
		radius = float(v_radius.get())
		pi = 3.1416
		calc = pi * (radius**2)
		text = 'วงกลมนี้มีพื้นที่ {:,.2f} {}'.format(calc,unit)
		print(text)
		v_result.set(text)
		v_radius.set('')
	except:
		messagebox.showwarning('กรอกตัวเลข','กรุณากรอกตัวเลขเท่านั้น')
		v_radius.set('')
		E1.focus()


B1 = ttk.Button(GUI,text='Calculate',command=Calculate)
B1.pack(ipadx=20,ipady=10)

# Check Enter
E1.bind('<Return>',Calculate)

v_result = StringVar()
v_result.set('----ผลลัพธ์----')
R1 = ttk.Label(GUI,textvariable=v_result,font=FONT2,foreground='green')
R1.pack(pady=20)

GUI.mainloop()